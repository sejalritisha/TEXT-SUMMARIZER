
import spacy
from spacy.lang.en.stop_words import STOP_WORDS
from string import punctuation
from heapq import nlargest
text=""" Chandrayaan-3 (CH-3) is currently on an ambitious journey to reach the moon, with the objective of achieving a soft landing, exploring the lunar surface, and collecting invaluable scientific data. This mission is a technological challenge undertaken by India, led by ISRO.

As the attention turns towards the approach and landing of CH-3 on the moon, it is the right time to reflect on the making of CH-3. The spacecraft is the result of a collaborative effort, involving a vast array of experts from nearly all ISRO centres and contributions from external partners. This article aims to shed light on these efforts and provide readers with a glimpse of the CH-3 endeavour.

A spacecraft carries payloads or scientific instruments in space. When it revolves Earth or a celestial body, it is referred to as a satellite – an artificial one. CH-3 consists of a lander, designed to gently touch down on the moon's surface, and a rover, ready to explore the lunar terrain upon the lander's successful landing. To propel the lander and rover towards the moon, CH-3 relies on a propulsion module (PM).

Space is an unforgiving environment, characterized by high vacuum and ionizing radiation. Due to the lack of possibilities for in-situ repairs, the development of space missions demands meticulous planning, design, testing, analysis, and review. It is a true example of "rocket science" that necessitates a multi-disciplinary team of domain experts working hand in hand with project execution teams, to tailor solutions for each specific mission."""

def summarizer(rawdocs):
 stopwords=list(STOP_WORDS)
 #print(stopwords)
 nlp=spacy.load('en_core_web_sm')
 doc=nlp(rawdocs)
 #print(dc)
 tokens=[token.text for token in dc]
 #print(tokens)
 word_freq={}#dictionary
 for word in dc:
  if word.text.lower() not in stopwords and word.text.lower() not in punctuation:
         if word.text not in word_freq.keys():
            word_freq[word.text]=1
         else:
            word_freq[word.text]+=1
 #print(word_freq)
 max_freq=max(word_freq.values())#maximum freq
 #print(max_freq)
 for word in word_freq.keys():
    word_freq[word]=word_freq[word]/max_freq
 #print(word_freq)#normalize freq
 sent_tokens=[sent for sent in dc.sents]
 #print(sent_tokens)#sentence
 sent_scores={}
 for sent in sent_tokens:
    for word in sent:
        if word.text in word_freq.keys():
            if sent not in sent_scores.keys():
                sent_scores[sent]=word_freq[word.text]
            else:
                sent_scores[sent]+=word_freq[word.text]
 # print(sent_scores)
 select_len=int(len(sent_tokens)*0.3)
 #print(select_len)
 summary=nlargest(select_len,sent_scores,key=sent_scores.get)
 #print(summary)
 final_summary=[word.text for word in summary]
 summary=' '.join(final_summary)
 #print(text)
 #print(summary)
 #print("Length of original text",len(text.split(' ')))
 #print("Length of summary text",len(summary.split(' ')))
 return summary,doc,len(rawdocs.split(' ')),len(summary.split(' '))